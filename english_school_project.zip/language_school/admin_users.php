<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit;
}

// کوئری آپدیت شده برای دریافت id ثبت‌نام و نمره
$sql = "SELECT enrollments.id AS enrollment_id, users.full_name, users.email, users.phone, courses.title AS course_title, enrollments.enrolled_at, enrollments.grade 
        FROM enrollments 
        JOIN users ON enrollments.user_id = users.id 
        JOIN courses ON enrollments.course_id = courses.id 
        ORDER BY enrollments.enrolled_at DESC";
$enrollments = $pdo->query($sql)->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت کاربران | پنل ادمین</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
    <style>body { font-family: 'Vazirmatn', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <aside class="w-64 bg-gray-900 text-white flex flex-col shadow-2xl">
        <div class="h-16 flex items-center justify-center border-b border-gray-800 font-bold text-xl">
            پنل مدیریت 🛠️
        </div>
        <nav class="flex-1 px-2 py-4 space-y-2">
            <a href="dashboard.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">🏠 بازگشت به داشبورد</a>
            <a href="admin_courses.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">📚 مدیریت دوره‌ها</a>
            <a href="admin_users.php" class="flex items-center px-4 py-2 bg-blue-600 text-white rounded transition">👥 دانشجویان و ثبت‌نام‌ها</a>
        </nav>
    </aside>

    <main class="flex-1 overflow-y-auto p-8">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">لیست دانشجویان ثبت‌نام شده</h1>
        
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <table class="w-full text-right">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="p-4 text-gray-600">نام دانشجو</th>
                        <th class="p-4 text-gray-600">ایمیل</th>
                        <th class="p-4 text-gray-600">دوره خریداری شده</th>
                        <th class="p-4 text-gray-600">نمره فعلی</th>
                        <th class="p-4 text-gray-600">تاریخ ثبت‌نام</th>
                        <th class="p-4 text-gray-600 text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php foreach ($enrollments as $item): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4 font-bold text-gray-800"><?php echo htmlspecialchars($item['full_name']); ?></td>
                        <td class="p-4 text-gray-500 text-sm"><?php echo htmlspecialchars($item['email']); ?></td>
                        <td class="p-4 text-blue-600 font-medium"><?php echo htmlspecialchars($item['course_title']); ?></td>
                        <td class="p-4">
                            <?php if($item['grade']): ?>
                                <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-bold"><?php echo htmlspecialchars($item['grade']); ?></span>
                            <?php else: ?>
                                <span class="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-xs">ثبت نشده</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-4 text-gray-400 text-sm"><?php echo date('Y/m/d', strtotime($item['enrolled_at'])); ?></td>
                        <td class="p-4 text-center">
                            <a href="edit_grade.php?id=<?php echo $item['enrollment_id']; ?>" class="inline-block bg-purple-100 text-purple-700 hover:bg-purple-200 px-3 py-2 rounded-lg text-sm font-bold transition">
                                📝 نمره و نظر
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if(empty($enrollments)) echo "<p class='p-6 text-center text-gray-500'>هنوز هیچ ثبت‌نامی انجام نشده است.</p>"; ?>
        </div>
    </main>
</body>
</html>