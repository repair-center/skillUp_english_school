<?php
session_start();
require 'includes/db.php';

// ۱. امنیت: اگر شناسه دوره نیست، برگرد داشبورد
if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$course_id = $_GET['id'];
$user_id = $_SESSION['user_id'] ?? null;
$message = "";

// ۲. دریافت اطلاعات دوره
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = :id");
$stmt->execute([':id' => $course_id]);
$course = $stmt->fetch();

if (!$course) {
    die("دوره یافت نشد!");
}

// ۳. بررسی اینکه آیا کاربر قبلاً ثبت‌نام کرده؟
$is_enrolled = false;
if ($user_id) {
    $check = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = :uid AND course_id = :cid");
    $check->execute([':uid' => $user_id, ':cid' => $course_id]);
    if ($check->fetch()) {
        $is_enrolled = true;
    }
}

// ۴. پردازش دکمه خرید (ثبت‌نام)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['enroll'])) {
    if (!$user_id) {
        header("Location: login.php"); // اگر لاگین نیست بفرست لاگین
        exit;
    }
    
    try {
        // ثبت در جدول enrollments
        $sql = "INSERT INTO enrollments (user_id, course_id) VALUES (:uid, :cid)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':uid' => $user_id, ':cid' => $course_id]);
        
        // رفرش صفحه برای آپدیت شدن وضعیت
        header("Location: course.php?id=$course_id&success=1");
        exit;
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>خطا: " . $e->getMessage() . "</div>";
    }
}

// پیام موفقیت بعد از خرید
if (isset($_GET['success'])) {
    $message = "<div class='bg-green-100 text-green-800 p-4 rounded-lg mb-6 border border-green-200 text-center font-bold text-lg'>🎉 تبریک! ثبت‌نام شما با موفقیت انجام شد.</div>";
    $is_enrolled = true;
}
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4">
        
        <a href="dashboard.php" class="text-blue-600 mb-6 inline-block hover:underline">← بازگشت به داشبورد</a>
        
        <?php echo $message; ?>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden flex flex-col md:flex-row">
            
            <div class="md:w-1/2 h-64 md:h-auto relative">
                <img src="<?php echo $course['image']; ?>" class="absolute inset-0 w-full h-full object-cover">
                <div class="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-bold">
                    <?php echo $course['level']; ?>
                </div>
            </div>

            <div class="md:w-1/2 p-8 flex flex-col justify-between">
                <div>
                    <h1 class="text-3xl font-extrabold text-gray-900 mb-4"><?php echo $course['title']; ?></h1>
                    
                    <div class="flex items-center gap-4 text-gray-500 text-sm mb-6">
                        <span>👨‍🏫 مدرس: تیم اسکیل‌آپ</span>
                        <span>⏱️ مدت: ۲۰ ساعت</span>
                    </div>

                    <p class="text-gray-600 leading-relaxed mb-8 text-justify">
                        <?php echo nl2br($course['description']); ?>
                    </p>
                </div>

                <div>
                    <div class="border-t pt-6 flex justify-between items-center">
                        <span class="text-gray-500">قیمت دوره:</span>
                        <span class="text-2xl font-bold text-blue-700"><?php echo number_format($course['price']); ?> تومان</span>
                    </div>

                    <div class="mt-6">
                        <?php if ($is_enrolled): ?>
                            <button disabled class="w-full bg-green-100 text-green-700 font-bold py-4 rounded-xl border border-green-300 cursor-default">
                                ✅ شما دانشجوی این دوره هستید
                            </button>
                            <a href="classroom.php?course_id=<?php echo $course['id']; ?>" class="block text-center mt-3 bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition shadow-md">
                            📺 ورود به کلاس و شروع یادگیری
                            </a>
                        <?php else: ?>
                            <form method="POST">
                                <button type="submit" name="enroll" class="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                    💳 پرداخت و ثبت‌نام آنلاین
                                </button>
                            </form>
                            <p class="text-xs text-center text-gray-400 mt-2">پرداخت امن از طریق درگاه بانکی (دمو)</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<?php include 'includes/footer.php'; ?>