<?php include 'includes/header.php'; ?>

<section class="bg-gradient-to-b from-blue-50 to-white py-20 relative overflow-hidden">
    <div class="absolute top-0 right-0 -mr-20 -mt-20 w-72 h-72 rounded-full bg-blue-200 opacity-40 blur-3xl"></div>
    <div class="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-blue-200 opacity-40 blur-3xl"></div>

    <div class="max-w-7xl mx-auto px-4 flex flex-col-reverse md:flex-row items-center relative z-10">
        
        <div class="w-full md:w-1/2 text-center md:text-right mt-12 md:mt-0">
            <div class="inline-block bg-blue-100 text-blue-700 font-bold px-4 py-2 rounded-full mb-6 text-sm">
                🚀 بهترین پلتفرم آموزش زبان
            </div>
            
            <h1 class="text-4xl md:text-6xl font-extrabold text-gray-900 mb-6 leading-tight">
                یادگیری زبان، <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">پلی به سوی آینده</span>
            </h1>
            
            <p class="text-lg text-gray-600 mb-8 max-w-lg mx-auto md:mx-0 leading-relaxed">
                با اساتید حرفه‌ای و متدهای روز دنیا، زبان مورد علاقه‌ت رو سریع، راحت و با لذت یاد بگیر. همین الان مسیر جدیدت رو شروع کن!
            </p>
            
            <div class="flex flex-col sm:flex-row justify-center md:justify-start gap-4">
                <a href="register.php" class="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2 transform hover:-translate-y-1">
                    شروع یادگیری
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clip-rule="evenodd" /></svg>
                </a>
                <a href="#" class="bg-white text-gray-700 border-2 border-gray-200 px-8 py-4 rounded-xl font-bold hover:bg-gray-50 hover:border-gray-300 transition flex items-center justify-center">
                    مشاوره رایگان
                </a>
            </div>
        </div>

        <div class="w-full md:w-1/2 flex justify-center relative">
            <img src="images/hero.png" class="w-full max-w-md drop-shadow-2xl transform hover:-translate-y-2 transition duration-500" alt="Online Learning">        </div>
        
    </div>
</section>

<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">چرا <span class="text-blue-600">اسکیل‌آپ</span>؟</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            
            <div class="bg-gray-50 p-8 rounded-2xl shadow-sm hover:shadow-xl transition duration-300 border border-gray-100">
                <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" /></svg>
                </div>
                <h3 class="font-bold text-xl mb-3 text-gray-800">اساتید مجرب</h3>
                <p class="text-gray-500 leading-relaxed">تدریس توسط بهترین اساتید با مدرک معتبر بین‌المللی و تجربه بالا.</p>
            </div>

            <div class="bg-gray-50 p-8 rounded-2xl shadow-sm hover:shadow-xl transition duration-300 border border-gray-100 transform md:-translate-y-4">
                <div class="w-16 h-16 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                </div>
                <h3 class="font-bold text-xl mb-3 text-gray-800">کلاس آنلاین</h3>
                <p class="text-gray-500 leading-relaxed">یادگیری از هر جای دنیا با پلتفرم اختصاصی، پخش ویدیو و رفع اشکال.</p>
            </div>

            <div class="bg-gray-50 p-8 rounded-2xl shadow-sm hover:shadow-xl transition duration-300 border border-gray-100">
                <div class="w-16 h-16 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                </div>
                <h3 class="font-bold text-xl mb-3 text-gray-800">تعیین سطح هوشمند</h3>
                <p class="text-gray-500 leading-relaxed">سنجش دقیق مهارت‌های شما پیش از شروع دوره برای انتخاب بهترین مسیر.</p>
            </div>

        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>