<?php
session_start();
require 'includes/db.php';

// امنیت: فقط ادمین (در آینده می‌تونه استاد هم باشه)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit;
}

if (!isset($_GET['id'])) {
    header("Location: admin_users.php"); exit;
}

$enrollment_id = $_GET['id'];
$message = "";

// ذخیره نمره و نظر
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grade = $_POST['grade'];
    $teacher_note = $_POST['teacher_note'];

    $sql = "UPDATE enrollments SET grade = :grade, teacher_note = :note WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':grade' => $grade, ':note' => $teacher_note, ':id' => $enrollment_id]);
    
    $message = "<div class='bg-green-100 text-green-700 p-4 rounded mb-4'>نمره و یادداشت با موفقیت ثبت شد! ✅</div>";
}

// گرفتن اطلاعات ثبت‌نام برای نمایش
$sql = "SELECT users.full_name, courses.title AS course_title, enrollments.grade, enrollments.teacher_note 
        FROM enrollments 
        JOIN users ON enrollments.user_id = users.id 
        JOIN courses ON enrollments.course_id = courses.id 
        WHERE enrollments.id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $enrollment_id]);
$enrollment = $stmt->fetch();

if (!$enrollment) {
    die("ثبت‌نام یافت نشد!");
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت نمره | پنل ادمین</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
    <style>body { font-family: 'Vazirmatn', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <aside class="w-64 bg-gray-900 text-white flex flex-col shadow-2xl">
        <div class="h-16 flex items-center justify-center border-b border-gray-800 font-bold text-xl">
            پنل مدیریت 🛠️
        </div>
        <nav class="flex-1 px-2 py-4 space-y-2">
            <a href="dashboard.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">🏠 بازگشت به داشبورد</a>
            <a href="admin_courses.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">📚 مدیریت دوره‌ها</a>
            <a href="admin_users.php" class="flex items-center px-4 py-2 bg-blue-600 text-white rounded transition">👥 دانشجویان و ثبت‌نام‌ها</a>
        </nav>
    </aside>

    <main class="flex-1 overflow-y-auto p-8">
        <div class="max-w-2xl mx-auto">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">ثبت کارنامه دانشجو</h1>
                <a href="admin_users.php" class="text-blue-600 hover:underline font-bold transition">← بازگشت به لیست</a>
            </div>

            <?php echo $message; ?>

            <div class="bg-white p-8 rounded-xl shadow-lg border-t-4 border-purple-500">
                <div class="mb-6 bg-gray-50 p-4 rounded-lg border border-gray-100">
                    <p class="text-sm text-gray-500 mb-2">دانشجو: <span class="font-bold text-gray-800 text-base"><?php echo htmlspecialchars($enrollment['full_name']); ?></span></p>
                    <p class="text-sm text-gray-500">دوره: <span class="font-bold text-blue-600 text-base"><?php echo htmlspecialchars($enrollment['course_title']); ?></span></p>
                </div>

                <form method="POST" class="space-y-5">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">نمره ارزیابی (مثلا: A+ یا 18/20)</label>
                        <input type="text" name="grade" value="<?php echo htmlspecialchars($enrollment['grade'] ?? ''); ?>" placeholder="نمره دانشجو را وارد کنید..." class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500" dir="ltr">
                    </div>

                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">یادداشت استاد (قابل مشاهده برای دانشجو و والدین)</label>
                        <textarea name="teacher_note" rows="5" placeholder="وضعیت پیشرفت، نقاط قوت و ضعف و توصیه‌ها..." class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500 leading-relaxed"><?php echo htmlspecialchars($enrollment['teacher_note'] ?? ''); ?></textarea>
                    </div>

                    <button type="submit" class="w-full bg-purple-600 text-white font-bold py-3 rounded-lg hover:bg-purple-700 transition shadow-md hover:shadow-lg">
                        💾 ثبت نمره و نظر
                    </button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>