<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); exit;
}

$message = "";
$user_id = $_SESSION['user_id'];

// آپدیت اطلاعات
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $avatar = $_POST['avatar']; // لینک عکس
    $bio = $_POST['bio'];

    try {
        $sql = "UPDATE users SET full_name=:fn, phone=:ph, avatar=:av, bio=:bio WHERE id=:id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':fn'=>$full_name, ':ph'=>$phone, ':av'=>$avatar, ':bio'=>$bio, ':id'=>$user_id]);
        
        // آپدیت نام در سشن
        $_SESSION['full_name'] = $full_name;
        $message = "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>پروفایل شما آپدیت شد! ✅</div>";
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>خطا: " . $e->getMessage() . "</div>";
    }
}

// گرفتن اطلاعات فعلی کاربر
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch();
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-4">
        <a href="dashboard.php" class="text-blue-600 mb-6 inline-block hover:underline">← بازگشت به داشبورد</a>
        
        <div class="bg-white p-8 rounded-2xl shadow-lg flex flex-col md:flex-row gap-8">
            
            <div class="md:w-1/3 text-center">
                <div class="w-32 h-32 rounded-full overflow-hidden mx-auto border-4 border-blue-100 mb-4">
                    <img src="<?php echo $user['avatar'] ? $user['avatar'] : 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'; ?>" class="w-full h-full object-cover">
                </div>
                <h2 class="font-bold text-xl"><?php echo $user['full_name']; ?></h2>
                <span class="text-gray-500 text-sm"><?php echo $user['role'] === 'admin' ? 'مدیر سیستم' : 'دانشجو'; ?></span>
            </div>

            <div class="md:w-2/3">
                <h1 class="text-2xl font-bold mb-6 border-b pb-2">ویرایش پروفایل</h1>
                <?php echo $message; ?>
                
                <form method="POST" class="space-y-4">
                    <div>
                        <label class="block text-sm font-bold text-gray-700">نام و نام خانوادگی</label>
                        <input type="text" name="full_name" value="<?php echo $user['full_name']; ?>" required class="w-full border rounded-lg p-3">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700">شماره موبایل</label>
                        <input type="text" name="phone" value="<?php echo $user['phone']; ?>" placeholder="0912..." class="w-full border rounded-lg p-3" dir="ltr">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700">لینک عکس پروفایل</label>
                        <input type="url" name="avatar" value="<?php echo $user['avatar']; ?>" placeholder="https://..." class="w-full border rounded-lg p-3 text-left" dir="ltr">
                        <p class="text-xs text-gray-400 mt-1">لینک مستقیم عکس خود را وارد کنید.</p>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700">درباره من (بیوگرافی)</label>
                        <textarea name="bio" rows="3" class="w-full border rounded-lg p-3" placeholder="علاقه مند به زبان..."><?php echo $user['bio']; ?></textarea>
                    </div>
                    <button type="submit" class="bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition w-full">ذخیره تغییرات</button>
                </form>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>