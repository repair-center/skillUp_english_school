<?php
session_start();
// تمام متغیرهای سشن رو پاک کن
session_unset();
// سشن رو کلاً نابود کن
session_destroy();
// کاربر رو بفرست صفحه اصلی
header("Location: index.php");
exit;
?>