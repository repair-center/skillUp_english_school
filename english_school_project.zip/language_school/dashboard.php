<?php
session_start();

// ۱. امنیت: اگر کاربر لاگین نیست، بفرستش صفحه ورود
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'includes/db.php';

// ۲. دریافت لیست دوره‌ها از دیتابیس
try {
    $sql = "SELECT * FROM courses ORDER BY id DESC";
    $stmt = $pdo->query($sql);
    $courses = $stmt->fetchAll();
} catch (PDOException $e) {
    die("خطا در دریافت دوره‌ها: " . $e->getMessage());
}
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen pb-12">
    
    <div class="bg-blue-800 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-end">
            <div>
                <h1 class="text-3xl font-bold">داشبورد کاربری</h1>
                <p class="mt-2 text-blue-200">
                    سلام <span class="font-bold text-white"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span> عزیز، به آکادمی خوش اومدی! 👋
                </p>
            </div>
            <a href="profile.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg backdrop-blur-sm transition text-sm flex items-center gap-2">
                ⚙️ ویرایش پروفایل
            </a>
        </div>
    </div>

<?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
    <div class="max-w-7xl mx-auto px-4 mb-8">
        <br>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 flex justify-between items-center rounded-lg shadow-md">
            <div>
                <p class="font-bold">حالت مدیریت فعال است</p>
                <p class="text-sm">شما دسترسی کامل به مدیریت دوره‌ها دارید.</p>
            </div>
            <a href="admin_courses.php" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-6 rounded-lg shadow transition flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.532 1.532 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.532 1.532 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd" /></svg>
                ورود به پنل مدیریت
            </a>
        </div>
        </br>
    </div>
    
    <?php endif; ?>

    <div class="max-w-7xl mx-auto px-4 -mt-8">
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div class="bg-white p-6 rounded-xl shadow-md border-b-4 border-blue-500">
                <div class="text-gray-500 text-sm">دوره‌های ثبت‌نام شده</div>
                <div class="text-3xl font-bold text-gray-800 mt-2">۰</div>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-md border-b-4 border-green-500">
                <div class="text-gray-500 text-sm">آزمون‌های پاس شده</div>
                <div class="text-3xl font-bold text-gray-800 mt-2">۰</div>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-md border-b-4 border-purple-500">
                <div class="text-gray-500 text-sm">سطح زبان شما</div>
                <div class="text-3xl font-bold text-gray-800 mt-2">تعیین نشده</div>
            </div>
        </div>

        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">دوره‌های پیشنهادی برای شما</h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php foreach ($courses as $course): ?>
            <div class="bg-white rounded-2xl shadow-sm hover:shadow-lg transition duration-300 overflow-hidden flex flex-col h-full">
                <div class="h-48 overflow-hidden bg-gray-200">
                    <img src="<?php echo $course['image']; ?>" alt="<?php echo $course['title']; ?>" class="w-full h-full object-cover hover:scale-110 transition duration-500">
                </div>
                
                <div class="p-6 flex-grow flex flex-col">
                    <div class="flex justify-between items-center mb-3">
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-bold">
                            <?php echo $course['level']; ?>
                        </span>
                        <span class="text-green-600 font-bold text-sm">
                            <?php echo number_format($course['price']); ?> تومان
                        </span>
                    </div>

                    <h3 class="text-xl font-bold text-gray-900 mb-2">
                        <?php echo $course['title']; ?>
                    </h3>
                    
                    <p class="text-gray-500 text-sm mb-4 line-clamp-2">
                        <?php echo $course['description']; ?>
                    </p>
                    
                    <div class="mt-auto">
                        <a href="course.php?id=<?php echo $course['id']; ?>" class="block w-full text-center bg-gray-900 text-white py-2 rounded-lg hover:bg-blue-600 transition font-medium">
    مشاهده و ثبت‌نام
</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</div>

<?php include 'includes/footer.php'; ?>