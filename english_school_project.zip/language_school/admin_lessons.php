<?php
session_start();
require 'includes/db.php';

// امنیت: فقط ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit;
}

if (!isset($_GET['course_id'])) {
    header("Location: admin_courses.php"); exit;
}

$course_id = $_GET['course_id'];
$message = "";

// افزودن درس جدید
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $video_url = $_POST['video_url'];
    $content = $_POST['content'];

    $sql = "INSERT INTO lessons (course_id, title, video_url, content) VALUES (:cid, :title, :vid, :txt)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':cid'=>$course_id, ':title'=>$title, ':vid'=>$video_url, ':txt'=>$content]);
    $message = "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>درس جدید اضافه شد! ✅</div>";
}

// حذف درس
if (isset($_GET['delete_lesson'])) {
    $pdo->prepare("DELETE FROM lessons WHERE id=?")->execute([$_GET['delete_lesson']]);
    $message = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>درس حذف شد 🗑️</div>";
}

// دریافت اطلاعات دوره
$course = $pdo->prepare("SELECT title FROM courses WHERE id=?");
$course->execute([$course_id]);
$course_title = $course->fetchColumn();

// دریافت لیست درس‌ها
$lessons = $pdo->prepare("SELECT * FROM lessons WHERE course_id=? ORDER BY id ASC");
$lessons->execute([$course_id]);
$lessons_list = $lessons->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4">
        
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">مدیریت درس‌های: <span class="text-blue-600"><?php echo $course_title; ?></span></h1>
            <a href="admin_courses.php" class="text-gray-600 hover:text-black">← بازگشت به لیست دوره‌ها</a>
        </div>

        <?php echo $message; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded-xl shadow-lg h-fit">
                <h2 class="font-bold mb-4 border-b pb-2">➕ افزودن درس جدید</h2>
                <form method="POST" class="space-y-4">
                    <input type="text" name="title" placeholder="عنوان درس (مثلا: جلسه اول)" required class="w-full border p-2 rounded">
                    
                    <div>
                        <input type="text" name="video_url" placeholder="لینک ویدیو (YouTube/Aparat)" required class="w-full border p-2 rounded text-left" dir="ltr">
                        <p class="text-xs text-gray-400 mt-1">لینک Embed یا مستقیم ویدیو را وارد کنید.</p>
                    </div>

                    <textarea name="content" rows="4" placeholder="توضیحات متنی این جلسه..." class="w-full border p-2 rounded"></textarea>
                    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">ثبت درس</button>
                </form>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-lg">
                <h2 class="font-bold mb-4 border-b pb-2">📚 لیست جلسات</h2>
                <ul class="space-y-3">
                    <?php foreach ($lessons_list as $lesson): ?>
                    <li class="flex justify-between items-center bg-gray-50 p-3 rounded border hover:bg-blue-50 transition">
                        <span class="font-medium"><?php echo $lesson['title']; ?></span>
                        <a href="admin_lessons.php?course_id=<?php echo $course_id; ?>&delete_lesson=<?php echo $lesson['id']; ?>" onclick="return confirm('حذف شود؟')" class="text-red-500 hover:text-red-700 text-sm">حذف 🗑️</a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php if(empty($lessons_list)) echo "<p class='text-gray-400 text-sm text-center mt-4'>هنوز درسی اضافه نشده.</p>"; ?>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>