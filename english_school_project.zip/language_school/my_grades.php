<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); exit;
}

$user_id = $_SESSION['user_id'];
$student_name = $_SESSION['full_name'];

// دریافت لیست دوره‌هایی که دانشجو در آن‌ها نمره گرفته است
$sql = "SELECT courses.title AS course_title, enrollments.grade, enrollments.teacher_note, enrollments.enrolled_at, users.full_name AS teacher_name 
        FROM enrollments 
        JOIN courses ON enrollments.course_id = courses.id 
        LEFT JOIN users ON courses.teacher_id = users.id
        WHERE enrollments.user_id = :uid AND enrollments.grade IS NOT NULL
        ORDER BY enrollments.id DESC";
        
$stmt = $pdo->prepare($sql);
$stmt->execute([':uid' => $user_id]);
$grades = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">🎓 کارنامه و گواهینامه‌های من</h1>

        <?php if (empty($grades)): ?>
            <div class="bg-white p-8 rounded-xl shadow text-center text-gray-500">
                <p class="text-lg">هنوز نمره‌ای برای شما ثبت نشده است.</p>
                <p class="text-sm mt-2">به محض ثبت نمره توسط استاد، کارنامه شما در اینجا نمایش داده می‌شود.</p>
            </div>
        <?php else: ?>
            <div class="space-y-12">
                <?php foreach ($grades as $grade): ?>
                    
                    <div class="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 p-8 md:p-12 rounded-lg shadow-2xl overflow-hidden border-8 border-double border-yellow-600">
                        
                        <div class="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none" style="background-image: repeating-linear-gradient(45deg, #d4af37 0, #d4af37 2px, transparent 2px, transparent 8px);"></div>
                        
                        <div class="flex justify-between items-start relative z-10 border-b-2 border-yellow-600/50 pb-6 mb-8">
                            <div>
                                <h2 class="text-3xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-600 mb-2">
                                    اسکیل‌آپ
                                </h2>
                                <p class="text-yellow-500/80 tracking-widest text-sm uppercase font-serif">Language Academy</p>
                            </div>
                            
                            <div class="w-24 h-24 md:w-32 md:h-32 bg-yellow-500 rounded-full flex items-center justify-center border-4 border-dashed border-yellow-200 shadow-[0_0_30px_rgba(212,175,55,0.4)] transform rotate-12">
                                <div class="w-20 h-20 md:w-28 md:h-28 border-2 border-yellow-100 rounded-full flex flex-col items-center justify-center text-yellow-900 font-bold text-center">
                                    <span class="text-xs">No. 1</span>
                                    <span class="text-lg md:text-xl border-t border-b border-yellow-900 my-1 px-2">Brand</span>
                                    <span class="text-[10px]">Certified</span>
                                </div>
                            </div>
                        </div>

                        <div class="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 text-yellow-100">
                            
                            <div class="bg-gray-800/50 p-6 rounded-xl border border-yellow-600/30 backdrop-blur-sm">
                                <ul class="space-y-4">
                                    <li class="flex justify-between border-b border-gray-700 pb-2">
                                        <span class="text-gray-400">نام دانشجو:</span>
                                        <span class="font-bold text-white"><?php echo htmlspecialchars($student_name); ?></span>
                                    </li>
                                    <li class="flex justify-between border-b border-gray-700 pb-2">
                                        <span class="text-gray-400">نام دوره:</span>
                                        <span class="font-bold text-white"><?php echo htmlspecialchars($grade['course_title']); ?></span>
                                    </li>
                                    <li class="flex justify-between border-b border-gray-700 pb-2">
                                        <span class="text-gray-400">استاد راهنما:</span>
                                        <span class="font-bold text-white"><?php echo htmlspecialchars($grade['teacher_name'] ?? 'تیم آموزشی'); ?></span>
                                    </li>
                                    <li class="flex justify-between pb-2">
                                        <span class="text-gray-400">تاریخ صدور:</span>
                                        <span class="font-bold text-white"><?php echo date('Y/m/d'); ?></span>
                                    </li>
                                </ul>
                            </div>

                            <div class="flex flex-col justify-center items-center bg-gray-800/50 p-6 rounded-xl border border-yellow-600/30 backdrop-blur-sm text-center">
                                <h3 class="text-gray-400 mb-2">نمره نهایی (Total Score)</h3>
                                <div class="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-br from-yellow-300 to-yellow-600 mb-4 drop-shadow-lg">
                                    <?php echo htmlspecialchars($grade['grade']); ?>
                                </div>
                                <?php if($grade['teacher_note']): ?>
                                    <div class="mt-4 p-3 bg-gray-900 rounded border border-gray-700 w-full text-right text-sm text-gray-300">
                                        <span class="block text-yellow-500 text-xs mb-1">💬 نظر استاد:</span>
                                        <?php echo nl2br(htmlspecialchars($grade['teacher_note'])); ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="relative z-10 mt-12 flex justify-between items-end">
                            <div class="text-center">
                                <div class="w-32 border-b-2 border-yellow-600/50 mb-2 mx-auto"></div>
                                <p class="text-yellow-500/80 text-sm">مُهر و امضای مدیریت</p>
                            </div>
                            <div class="text-left text-yellow-500/50 text-xs">
                                <p>آکادمی زبان اسکیل‌آپ</p>
                                <p>www.SkillUp.ir</p>
                            </div>
                        </div>

                    </div>
                    <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>