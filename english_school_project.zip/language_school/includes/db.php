<?php
$host = "localhost";
$dbname = "school_db";
$user = "postgres"; // یوزر پیش‌فرض پستگرس
$password = "radepa@1221."; // !!! اینجا رمز پستگرس خودت رو بنویس !!!

try {
    // ساخت رشته اتصال
    $dsn = "pgsql:host=$host;port=5432;dbname=$dbname;";
    
    // ایجاد ارتباط
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // اگر پیام زیر رو دیدی یعنی همه چی عالیه
    //echo "<h3>اتصال به دیتابیس با موفقیت انجام شد! ✅</h3>";

} catch (PDOException $e) {
    echo "<h3>خطا در اتصال: ❌</h3>" . $e->getMessage();
}
?>