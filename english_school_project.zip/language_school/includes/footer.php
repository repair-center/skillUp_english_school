<footer class="bg-gray-800 text-white py-8 mt-auto">
    <div class="max-w-7xl mx-auto px-4 text-center">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 text-right">
            <div>
                <h4 class="font-bold mb-4">درباره اسکیل‌آپ</h4>
                <p class="text-gray-400 text-sm">ما اینجا هستیم تا یادگیری زبان رو براتون ساده و لذت‌بخش کنیم.</p>
            </div>
            <div>
                <h4 class="font-bold mb-4">لینک‌های مفید</h4>
                <ul class="text-gray-400 text-sm space-y-2">
                    <li><a href="#" class="hover:text-white">قوانین و مقررات</a></li>
                    <li><a href="#" class="hover:text-white">سوالات متداول</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold mb-4">تماس با ما</h4>
                <p class="text-gray-400 text-sm">تلفن: ۰۲۱-۱۲۳۴۵۶۷۸<br>ایمیل: info@skillup.ir</p>
            </div>
        </div>
        <div class="border-t border-gray-700 pt-4">
            <p class="text-sm text-gray-500">© 2024 تمامی حقوق محفوظ است.</p>
        </div>
    </div>
</footer>

</body>
</html>