<?php
// بررسی و شروع سشن (اگر استارت نشده باشد)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>آکادمی زبان اسکیل‌آپ | SkillUp</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
    
    <style>
        body { font-family: 'Vazirmatn', sans-serif; }
        /* کلاسی برای نمایش نرم منوی کشویی */
        .dropdown-menu { display: none; }
        .group:hover .dropdown-menu { display: block; animation: fadeIn 0.2s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

<nav class="bg-white shadow-md sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            
            <div class="flex items-center">
                <div class="flex-shrink-0 flex items-center gap-2">
                    <a href="index.php" class="text-2xl font-bold text-blue-600">SkillUp</a>
                </div>
                
                <div class="hidden md:flex md:space-x-8 md:space-x-reverse md:mr-10">
                    <a href="index.php" class="text-gray-900 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition">خانه</a>
                    <a href="dashboard.php" class="text-gray-500 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition">دوره‌ها</a>
                    <a href="#" class="text-gray-500 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition">اساتید</a>
                </div>
            </div>

            <div class="flex items-center space-x-4 space-x-reverse">
                <?php if (isset($_SESSION['user_id'])): ?>
                    
                    <div class="hidden md:flex items-center gap-4 ml-4">
                        <a href="dashboard.php" class="text-blue-600 font-bold hover:text-blue-800 transition flex items-center gap-1 text-sm bg-blue-50 px-3 py-2 rounded-lg">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                            </svg>
                            داشبورد من
                        </a>
                        
                        <span class="text-gray-300">|</span>
                        
                        <div class="relative group cursor-pointer py-4">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-sm">
                                    <?php echo mb_substr($_SESSION['full_name'] ?? 'ک', 0, 1, 'UTF-8'); ?>
                                </div>
                                <span class="text-sm text-gray-700 font-bold flex items-center gap-1 hover:text-blue-600 transition">
                                    <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'کاربر'); ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                                </span>
                            </div>

                            <div class="dropdown-menu absolute left-0 top-full mt-0 w-56 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50">
                                <div class="p-2 space-y-1">
                                    <div class="px-4 py-2 border-b border-gray-50 mb-2">
                                        <p class="text-xs text-gray-400">سطح دسترسی:</p>
                                        

                                         <?php 
        if($_SESSION['role'] === 'admin') echo 'مدیر سیستم 👑';
        elseif($_SESSION['role'] === 'teacher') echo 'استاد 👨‍🏫';
        else echo 'دانشجو 🎓'; 
        ?>


                                    </div>
                                    
                                    <a href="profile.php" class="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition">
                                        <span>⚙️</span> ویرایش پروفایل
                                    </a>
                                    


                                    <?php if($_SESSION['role'] === 'teacher'): ?>
    <a href="teacher_panel.php" class="flex items-center gap-2 px-4 py-2 text-sm text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition font-bold">
        <span>📝</span> مدیریت نمرات کلاس
    </a>
<?php else: ?>
    <a href="my_grades.php" class="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-yellow-50 hover:text-yellow-600 rounded-lg transition font-bold">
        <span>📊</span> کارنامه و نمرات
    </a>
<?php endif; ?>


                                    <a href="#" class="flex items-center gap-2 px-4 py-2 text-sm text-gray-400 hover:bg-gray-50 cursor-not-allowed rounded-lg transition" title="به زودی اضافه می‌شود">
                                        <span>🔔</span> یادداشت‌های استاد <span class="bg-gray-100 text-[10px] px-2 rounded-full ml-auto">بزودی</span>
                                    </a>
                                    
                                    <div class="border-t border-gray-100 my-1"></div>
                                    
                                    <a href="logout.php" class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition font-bold">
                                        <span>🚪</span> خروج از حساب
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>

                <?php else: ?>
                    
                    <a href="login.php" class="text-gray-500 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-bold hidden md:block transition">ورود به حساب</a>
                    <a href="register.php" class="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                        ثبت‌نام رایگان
                    </a>

                <?php endif; ?>
            </div>
            
        </div>
    </div>
</nav>