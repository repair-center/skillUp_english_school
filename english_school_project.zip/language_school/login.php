<?php
session_start();

// اگر کاربر قبلاً لاگین کرده، مستقیم بفرستش صفحه اصلی
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

require 'includes/db.php';

$error = '';

// بررسی ارسال فرم
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "لطفاً ایمیل و رمز عبور را وارد کنید.";
    } else {
        // جستجوی کاربر در دیتابیس
        $sql = "SELECT * FROM users WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        // بررسی پسورد
        if ($user && password_verify($password, $user['password'])) {
            // ورود موفق: ذخیره اطلاعات در سشن
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name']; // اینجا نام کامل رو ذخیره کردیم
            $_SESSION['role'] = $user['role'];

            // هدایت به صفحه اصلی
            header("Location: index.php");
            exit;
        } else {
            $error = "ایمیل یا رمز عبور اشتباه است.";
        }
    }
}
?>

<?php include 'includes/header.php'; ?>

<div class="flex-grow flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
        <div class="text-center mb-8">
            <h2 class="text-3xl font-extrabold text-gray-900">ورود به حساب کاربری</h2>
            <p class="text-gray-500 mt-2">خوش آمدید! لطفاً وارد شوید.</p>
        </div>

        <?php if($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-center">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form class="space-y-6" action="login.php" method="POST">
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">آدرس ایمیل</label>
                <input id="email" name="email" type="email" required class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" dir="ltr">
            </div>

            <div>
                <label for="password" class="block text-sm font-medium text-gray-700">رمز عبور</label>
                <input id="password" name="password" type="password" required class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" dir="ltr">
            </div>

            <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition">
                ورود
            </button>
        </form>

        <div class="mt-6 text-center text-sm">
            <p class="text-gray-600">
                هنوز عضو نشده‌اید؟ 
                <a href="register.php" class="font-medium text-blue-600 hover:text-blue-500 transition">ثبت‌نام کنید</a>
            </p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>