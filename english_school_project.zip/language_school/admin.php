<?php
session_start();
require 'includes/db.php';

// ۱. چک امنیتی (فقط ادمین)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$message = "";

// ۲. عملیات حذف دوره
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $message = "<div class='bg-green-100 text-green-700 p-4 rounded mb-4'>دوره با موفقیت حذف شد! 🗑️</div>";
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-4 rounded mb-4'>خطا در حذف: " . $e->getMessage() . "</div>";
    }
}

// ۳. عملیات افزودن دوره جدید
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $level = $_POST['level'];
    $image = $_POST['image'];

    try {
        $sql = "INSERT INTO courses (title, description, price, level, image) VALUES (:title, :description, :price, :level, :image)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':title' => $title, ':description' => $description, ':price' => $price, ':level' => $level, ':image' => $image]);
        $message = "<div class='bg-green-100 text-green-700 p-4 rounded mb-4'>دوره جدید اضافه شد! ✅</div>";
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-4 rounded mb-4'>خطا: " . $e->getMessage() . "</div>";
    }
}

// ۴. دریافت لیست تمام دوره‌ها برای نمایش در جدول
$courses = $pdo->query("SELECT * FROM courses ORDER BY id DESC")->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4">
        
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">پنل مدیریت</h1>
            <a href="dashboard.php" class="text-blue-600 font-bold hover:underline">بازگشت به داشبورد</a>
        </div>

        <?php echo $message; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div class="lg:col-span-1">
                <div class="bg-white p-6 rounded-xl shadow-lg sticky top-24">
                    <h2 class="text-xl font-bold mb-4 text-gray-700 border-b pb-2">➕ افزودن دوره جدید</h2>
                    <form method="POST" action="admin.php" class="space-y-4">
                        <div>
                            <label class="block text-sm font-bold text-gray-700">عنوان</label>
                            <input type="text" name="title" required class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700">سطح</label>
                            <select name="level" class="w-full px-3 py-2 border rounded-lg">
                                <option value="مبتدی (A1)">مبتدی (A1)</option>
                                <option value="متوسط (B1)">متوسط (B1)</option>
                                <option value="پیشرفته (C1)">پیشرفته (C1)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700">قیمت</label>
                            <input type="number" name="price" required class="w-full px-3 py-2 border rounded-lg">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700">عکس (URL)</label>
                            <input type="url" name="image" required class="w-full px-3 py-2 border rounded-lg text-left" dir="ltr">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700">توضیحات</label>
                            <textarea name="description" rows="3" required class="w-full px-3 py-2 border rounded-lg"></textarea>
                        </div>
                        <button type="submit" class="w-full bg-blue-600 text-white font-bold py-2 rounded-lg hover:bg-blue-700 transition">ثبت دوره</button>
                    </form>
                </div>
            </div>

            <div class="lg:col-span-2">
                <div class="bg-white p-6 rounded-xl shadow-lg">
                    <h2 class="text-xl font-bold mb-4 text-gray-700 border-b pb-2">📋 لیست دوره‌های موجود</h2>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-right">
                            <thead class="bg-gray-50 text-gray-600 text-sm">
                                <tr>
                                    <th class="p-3">تصویر</th>
                                    <th class="p-3">عنوان</th>
                                    <th class="p-3">قیمت</th>
                                    <th class="p-3">عملیات</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php foreach ($courses as $course): ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="p-3">
                                        <img src="<?php echo $course['image']; ?>" class="w-12 h-12 rounded object-cover">
                                    </td>
                                    <td class="p-3 font-medium text-gray-800"><?php echo $course['title']; ?></td>
                                    <td class="p-3 text-sm text-gray-500"><?php echo number_format($course['price']); ?></td>
                                    <td class="p-3 flex gap-2">
                                        <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="bg-blue-100 text-blue-600 px-3 py-1 rounded text-sm hover:bg-blue-200">
                                            ویرایش
                                        </a>
                                        <a href="admin.php?delete_id=<?php echo $course['id']; ?>" onclick="return confirm('آیا از حذف این دوره مطمئن هستید؟')" class="bg-red-100 text-red-600 px-3 py-1 rounded text-sm hover:bg-red-200">
                                            حذف
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>