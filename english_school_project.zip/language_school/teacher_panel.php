<?php
session_start();
require 'includes/db.php';

// امنیت: فقط استاد حق ورود دارد
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: index.php"); exit;
}

$teacher_id = $_SESSION['user_id'];
$message = "";

// پردازش ثبت نمره
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['enrollment_id'])) {
    $enrollment_id = $_POST['enrollment_id'];
    
    // دریافت ریزنمرات
    $speaking = (int)$_POST['score_speaking'];
    $writing = (int)$_POST['score_writing'];
    $reading = (int)$_POST['score_reading'];
    $listening = (int)$_POST['score_listening'];
    $activity = (int)$_POST['score_activity'];
    $teacher_note = $_POST['teacher_note'];

    // محاسبه نمره کل (از 100)
    $total_grade = $speaking + $writing + $reading + $listening + $activity;

    try {
        $sql = "UPDATE enrollments SET 
                score_speaking = :sp, 
                score_writing = :wr, 
                score_reading = :re, 
                score_listening = :li, 
                score_activity = :ac, 
                grade = :total, 
                teacher_note = :note 
                WHERE id = :eid";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':sp' => $speaking, ':wr' => $writing, ':re' => $reading, 
            ':li' => $listening, ':ac' => $activity, 
            ':total' => $total_grade, ':note' => $teacher_note, ':eid' => $enrollment_id
        ]);
        $message = "<div class='bg-green-100 border-r-4 border-green-500 text-green-700 p-4 rounded mb-6 font-bold shadow-sm'>✅ نمره و کارنامه دانشجو با موفقیت صادر شد! (نمره کل: $total_grade از 100)</div>";
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-4 rounded mb-6'>خطا در ثبت: " . $e->getMessage() . "</div>";
    }
}

// گرفتن لیست کلاس‌ها و دانشجوهای مختص همین استاد
$sql = "SELECT e.id AS enrollment_id, u.full_name AS student_name, c.title AS course_title, e.grade, e.enrolled_at 
        FROM enrollments e 
        JOIN users u ON e.user_id = u.id 
        JOIN courses c ON e.course_id = c.id 
        WHERE c.teacher_id = :tid 
        ORDER BY e.enrolled_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([':tid' => $teacher_id]);
$students = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4">
        
        <div class="flex items-center gap-3 mb-8 border-b pb-4">
            <span class="text-4xl">👨‍🏫</span>
            <div>
                <h1 class="text-2xl font-extrabold text-gray-800">پنل مدیریت کلاس‌ها</h1>
                <p class="text-gray-500 text-sm mt-1">استاد عزیز، به بخش ثبت نمرات خوش آمدید.</p>
            </div>
        </div>

        <?php echo $message; ?>

        <?php if (isset($_GET['grade_id'])): 
            // بخش فرم ثبت نمره
            $grade_id = $_GET['grade_id'];
            $stmt = $pdo->prepare("SELECT e.*, u.full_name, c.title FROM enrollments e JOIN users u ON e.user_id = u.id JOIN courses c ON e.course_id = c.id WHERE e.id = ?");
            $stmt->execute([$grade_id]);
            $current = $stmt->fetch();
        ?>
            <div class="bg-white p-8 rounded-2xl shadow-xl border border-gray-100 max-w-3xl mx-auto">
                <div class="flex justify-between items-center mb-6 border-b pb-4">
                    <h2 class="text-xl font-bold text-purple-700">ثبت ریزنمرات دانشجو</h2>
                    <a href="teacher_panel.php" class="text-gray-500 hover:text-gray-800">← بازگشت به لیست</a>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg mb-6 flex justify-between">
                    <div><span class="text-gray-500 text-sm">دانشجو:</span> <span class="font-bold text-gray-800"><?php echo htmlspecialchars($current['full_name']); ?></span></div>
                    <div><span class="text-gray-500 text-sm">دوره:</span> <span class="font-bold text-gray-800"><?php echo htmlspecialchars($current['title']); ?></span></div>
                </div>

                <form method="POST" class="space-y-6">
                    <input type="hidden" name="enrollment_id" value="<?php echo $grade_id; ?>">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-6 rounded-xl border border-gray-200">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">🗣️ Speaking (از 20)</label>
                            <input type="number" name="score_speaking" min="0" max="20" value="<?php echo $current['score_speaking'] ?? 0; ?>" required class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">✍️ Writing (از 30)</label>
                            <input type="number" name="score_writing" min="0" max="30" value="<?php echo $current['score_writing'] ?? 0; ?>" required class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">📖 Reading (از 10)</label>
                            <input type="number" name="score_reading" min="0" max="10" value="<?php echo $current['score_reading'] ?? 0; ?>" required class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">🎧 Listening (از 20)</label>
                            <input type="number" name="score_listening" min="0" max="20" value="<?php echo $current['score_listening'] ?? 0; ?>" required class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-bold text-gray-700 mb-2">⭐ فعالیت کلاسی (از 20)</label>
                            <input type="number" name="score_activity" min="0" max="20" value="<?php echo $current['score_activity'] ?? 0; ?>" required class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">توصیه استاد برای کارنامه (انتخابی)</label>
                        <textarea name="teacher_note" rows="3" placeholder="نقاط قوت و ضعف دانشجو را برای نمایش در کارنامه بنویسید..." class="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500"><?php echo htmlspecialchars($current['teacher_note'] ?? ''); ?></textarea>
                    </div>

                    <button type="submit" class="w-full bg-purple-600 text-white font-bold py-4 rounded-xl hover:bg-purple-700 transition shadow-lg text-lg">
                        صدور نهایی کارنامه
                    </button>
                </form>
            </div>

        <?php else: 
            // بخش نمایش لیست دانشجویان
        ?>
            <div class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
                <table class="w-full text-right">
                    <thead class="bg-gray-100 text-gray-600">
                        <tr>
                            <th class="p-4">نام دانشجو</th>
                            <th class="p-4">دوره آموزشی</th>
                            <th class="p-4">نمره کل (از ۱۰۰)</th>
                            <th class="p-4">تاریخ ثبت‌نام</th>
                            <th class="p-4 text-center">عملیات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($students as $student): ?>
                        <tr class="hover:bg-purple-50/50 transition">
                            <td class="p-4 font-bold text-gray-800"><?php echo htmlspecialchars($student['student_name']); ?></td>
                            <td class="p-4 text-purple-700 font-medium"><?php echo htmlspecialchars($student['course_title']); ?></td>
                            <td class="p-4">
                                <?php if($student['grade'] !== null): ?>
                                    <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-bold"><?php echo $student['grade']; ?></span>
                                <?php else: ?>
                                    <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs">در انتظار نمره</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-4 text-sm text-gray-500"><?php echo date('Y/m/d', strtotime($student['enrolled_at'])); ?></td>
                            <td class="p-4 text-center">
                                <a href="teacher_panel.php?grade_id=<?php echo $student['enrollment_id']; ?>" class="inline-block bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 rounded-lg text-sm font-bold shadow transition transform hover:-translate-y-0.5">
                                    ثبت / ویرایش نمره
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if(empty($students)) echo "<div class='p-8 text-center text-gray-500'>هنوز هیچ دانشجویی در دوره‌های شما ثبت‌نام نکرده است.</div>"; ?>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php include 'includes/footer.php'; ?>