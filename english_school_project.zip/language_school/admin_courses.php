<?php
session_start();
require 'includes/db.php';

// دریافت لیست اساتید برای نمایش در فرم
$teachers = $pdo->query("SELECT id, full_name FROM users WHERE role = 'teacher'")->fetchAll();

// امنیت: فقط ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$message = "";

// عملیات حذف دوره
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM courses WHERE id = :id");
    $stmt->execute([':id' => $_GET['delete_id']]);
    $message = "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>دوره حذف شد 🗑️</div>";
}

// عملیات افزودن دوره
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // اصلاح دستور SQL برای دریافت آیدی مدرس
    $sql = "INSERT INTO courses (title, description, price, level, image, teacher_id) VALUES (:title, :description, :price, :level, :image, :teacher_id)";
    $stmt = $pdo->prepare($sql);
    
    // مدیریت انتخاب مدرس (اگر انتخاب نشده بود، مقدار null ارسال شود)
    $teacher_id = !empty($_POST['teacher_id']) ? $_POST['teacher_id'] : null;

    $stmt->execute([
        ':title' => $_POST['title'],
        ':description' => $_POST['description'],
        ':price' => $_POST['price'],
        ':level' => $_POST['level'],
        ':image' => $_POST['image'], // ویرگول جا افتاده اینجا بود
        ':teacher_id' => $teacher_id // نام متغیر هم اصلاح شد
    ]);
    $message = "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>دوره جدید ساخته شد ✅</div>";
}

$courses = $pdo->query("SELECT * FROM courses ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت دوره‌ها | پنل ادمین</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
    <style>body { font-family: 'Vazirmatn', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <aside class="w-64 bg-gray-900 text-white flex flex-col shadow-2xl">
        <div class="h-16 flex items-center justify-center border-b border-gray-800 font-bold text-xl">
            پنل مدیریت 🛠️
        </div>
        <nav class="flex-1 px-2 py-4 space-y-2">
            <a href="dashboard.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">
                🏠 بازگشت به داشبورد
            </a>
            <a href="admin_courses.php" class="flex items-center px-4 py-2 bg-blue-600 text-white rounded transition">
                📚 مدیریت دوره‌ها
            </a>
            <a href="admin_users.php" class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-800 rounded transition">
                👥 دانشجویان و ثبت‌نام‌ها
            </a>
            <a href="logout.php" class="flex items-center px-4 py-2 text-red-400 hover:bg-gray-800 rounded transition mt-8">
                🚪 خروج
            </a>
        </nav>
    </aside>

    <main class="flex-1 overflow-y-auto p-8">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">مدیریت دوره‌های آموزشی</h1>
        <?php echo $message; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-xl shadow-lg h-fit">
                <h2 class="font-bold mb-4 border-b pb-2">➕ دوره جدید</h2>
                <form method="POST" class="space-y-3">
                    <input type="text" name="title" placeholder="عنوان دوره" required class="w-full border p-2 rounded">
                    <select name="level" class="w-full border p-2 rounded">
                        <option value="مبتدی (A1)">مبتدی (A1)</option>
                        <option value="متوسط (B1)">متوسط (B1)</option>
                        <option value="پیشرفته (C1)">پیشرفته (C1)</option>
                    </select>
                    <input type="number" name="price" placeholder="قیمت (تومان)" required class="w-full border p-2 rounded">
                    <input type="url" name="image" placeholder="لینک تصویر" required class="w-full border p-2 rounded text-left" dir="ltr">
                    <textarea name="description" rows="3" placeholder="توضیحات..." required class="w-full border p-2 rounded"></textarea>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">مدرس دوره</label>
                        <select name="teacher_id" class="w-full border p-2 rounded bg-white">
                            <option value="">-- بدون مدرس (خودآموز) --</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['id']; ?>">👨‍🏫 <?php echo $teacher['full_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">ثبت دوره</button>
                </form>
            </div>

            <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
                <h2 class="font-bold mb-4 border-b pb-2">📋 لیست دوره‌ها</h2>
                <table class="w-full text-right text-sm">
                    <thead>
                        <tr class="bg-gray-50 text-gray-600"><th class="p-2">تصویر</th><th class="p-2">عنوان</th><th class="p-2">قیمت</th><th class="p-2">عملیات</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                        <tr class="border-b">
                            <td class="p-2"><img src="<?php echo $course['image']; ?>" class="w-10 h-10 rounded"></td>
                            <td class="p-2 font-bold"><?php echo $course['title']; ?></td>
                            <td class="p-2"><?php echo number_format($course['price']); ?></td>
                            <td class="p-2 flex gap-2">
                                <a href="admin_lessons.php?course_id=<?php echo $course['id']; ?>" class="text-yellow-700 bg-yellow-100 px-2 py-1 rounded text-xs font-bold border border-yellow-200 hover:bg-yellow-200">
                                📂 درس‌ها
                                </a>
                                <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="text-blue-600 bg-blue-100 px-2 py-1 rounded text-xs">ویرایش</a>
                                <a href="admin_courses.php?delete_id=<?php echo $course['id']; ?>" onclick="return confirm('حذف شود؟')" class="text-red-600 bg-red-100 px-2 py-1 rounded text-xs">حذف</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>