<?php
require 'includes/db.php'; 
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $sql = "INSERT INTO users (full_name, email, password) VALUES (:full_name, :email, :password)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':full_name' => $full_name, ':email' => $email, ':password' => $hashed_password]);
        $message = "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-center'>ثبت‌نام موفق! <a href='login.php' class='font-bold underline'>وارد شوید</a>.</div>";
    } catch (PDOException $e) {
        if ($e->getCode() == '23505') {
            $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-center'>این ایمیل تکراری است!</div>";
        } else {
            $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-center'>خطا در ثبت‌نام.</div>";
        }
    }
}
?>
<?php include 'includes/header.php'; ?>

<div class="flex-grow flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
        <h2 class="text-3xl font-bold text-center mb-8">عضویت در اسکیل‌آپ</h2>
        <?php echo $message; ?>
        <form class="space-y-6" action="register.php" method="POST">
            <div><label class="block text-sm font-medium">نام کامل</label><input name="full_name" type="text" required class="mt-1 block w-full px-4 py-3 border rounded-lg"></div>
            <div><label class="block text-sm font-medium">ایمیل</label><input name="email" type="email" required class="mt-1 block w-full px-4 py-3 border rounded-lg" dir="ltr"></div>
            <div><label class="block text-sm font-medium">رمز عبور</label><input name="password" type="password" required class="mt-1 block w-full px-4 py-3 border rounded-lg" dir="ltr"></div>
            <button type="submit" class="w-full py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700">ثبت‌نام</button>
        </form>
        <p class="mt-6 text-center text-sm">قبلاً ثبت‌نام کرده‌اید؟ <a href="login.php" class="text-blue-600">وارد شوید</a></p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>