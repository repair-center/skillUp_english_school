<?php
session_start();
require 'includes/db.php';

// امنیت: فقط ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// اگر شناسه دوره موجود نباشد برگرد به پنل
if (!isset($_GET['id'])) {
    header("Location: admin.php");
    exit;
}

$id = $_GET['id'];
$message = "";

// ۲. پردازش فرم ویرایش (Update)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $level = $_POST['level'];
    $image = $_POST['image'];

    try {
        $sql = "UPDATE courses SET title=:title, description=:description, price=:price, level=:level, image=:image WHERE id=:id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':price' => $price,
            ':level' => $level,
            ':image' => $image,
            ':id' => $id
        ]);
        $message = "<div class='bg-green-100 text-green-700 p-4 rounded mb-4'>دوره ویرایش شد! ✅ <a href='admin.php' class='underline'>بازگشت</a></div>";
    } catch (PDOException $e) {
        $message = "<div class='bg-red-100 text-red-700 p-4 rounded mb-4'>خطا: " . $e->getMessage() . "</div>";
    }
}

// ۱. دریافت اطلاعات فعلی دوره برای نمایش در فرم
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = :id");
$stmt->execute([':id' => $id]);
$course = $stmt->fetch();

if (!$course) {
    die("دوره مورد نظر یافت نشد!");
}
?>

<?php include 'includes/header.php'; ?>

<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-2xl mx-auto px-4">
        <div class="bg-white p-8 rounded-xl shadow-lg">
            <h2 class="text-xl font-bold mb-6 text-gray-800">✏️ ویرایش دوره: <?php echo $course['title']; ?></h2>
            
            <?php echo $message; ?>

            <form method="POST" class="space-y-5">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">عنوان دوره</label>
                    <input type="text" name="title" value="<?php echo $course['title']; ?>" required class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">سطح</label>
                        <select name="level" class="w-full px-4 py-3 border rounded-lg">
                            <option value="<?php echo $course['level']; ?>" selected>فعلی: <?php echo $course['level']; ?></option>
                            <option value="مبتدی (A1)">مبتدی (A1)</option>
                            <option value="متوسط (B1)">متوسط (B1)</option>
                            <option value="پیشرفته (C1)">پیشرفته (C1)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">قیمت</label>
                        <input type="number" name="price" value="<?php echo $course['price']; ?>" required class="w-full px-4 py-3 border rounded-lg">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">لینک تصویر</label>
                    <input type="url" name="image" value="<?php echo $course['image']; ?>" required class="w-full px-4 py-3 border rounded-lg text-left" dir="ltr">
                </div>

                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">توضیحات</label>
                    <textarea name="description" rows="5" required class="w-full px-4 py-3 border rounded-lg"><?php echo $course['description']; ?></textarea>
                </div>

                <div class="flex gap-4">
                    <button type="submit" class="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition">ذخیره تغییرات</button>
                    <a href="admin.php" class="w-1/3 bg-gray-200 text-gray-700 text-center py-3 rounded-lg hover:bg-gray-300 transition font-bold">لغو</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>