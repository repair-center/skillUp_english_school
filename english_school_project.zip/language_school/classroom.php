<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['course_id'])) {
    header("Location: dashboard.php"); exit;
}

$user_id = $_SESSION['user_id'];
$course_id = $_GET['course_id'];

// ۱. چک کردن ثبت‌نام (خیلی مهم: اگر نخریده باشه نباید ببینه)
$check = $pdo->prepare("SELECT * FROM enrollments WHERE user_id=? AND course_id=?");
$check->execute([$user_id, $course_id]);
if (!$check->fetch()) {
    die("<div style='text-align:center; margin-top:50px; font-family:tahoma;'>⛔ دسترسی غیرمجاز! شما در این دوره ثبت‌نام نکرده‌اید. <a href='course.php?id=$course_id'>خرید دوره</a></div>");
}

// ۲. دریافت اطلاعات دوره
$course = $pdo->prepare("SELECT title FROM courses WHERE id=?");
$course->execute([$course_id]);
$course_title = $course->fetchColumn();

// ۳. دریافت لیست درس‌ها
$lessons = $pdo->prepare("SELECT * FROM lessons WHERE course_id=? ORDER BY id ASC");
$lessons->execute([$course_id]);
$all_lessons = $lessons->fetchAll();

// ۴. پیدا کردن درس فعلی (برای نمایش)
$active_lesson_id = $_GET['lesson_id'] ?? ($all_lessons[0]['id'] ?? null);
$current_lesson = null;

if ($active_lesson_id) {
    foreach ($all_lessons as $l) {
        if ($l['id'] == $active_lesson_id) {
            $current_lesson = $l;
            break;
        }
    }
}




// ... کدای قبلی ...

// ۵. دریافت اطلاعات استاد دوره
$stmt = $pdo->prepare("SELECT users.id, users.full_name, users.avatar FROM courses JOIN users ON courses.teacher_id = users.id WHERE courses.id = ?");
$stmt->execute([$course_id]);
$teacher_info = $stmt->fetch();

// ۶. ارسال پیام جدید
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['chat_message'])) {
    $msg = trim($_POST['chat_message']);
    if (!empty($msg)) {
        // اگر کسی که پیام میده، خودِ استادِ این دوره باشه، تیک پاسخ استاد میخوره
        $is_teacher = ($teacher_info && $_SESSION['user_id'] == $teacher_info['id']) ? true : false;
        
        $stmt = $pdo->prepare("INSERT INTO course_chats (course_id, user_id, message, is_teacher_reply) VALUES (?, ?, ?, ?)");
        $stmt->execute([$course_id, $_SESSION['user_id'], $msg, $is_teacher ? 1 : 0]);
        
        // رفرش صفحه برای دیدن پیام
        header("Location: classroom.php?course_id=$course_id&lesson_id=" . ($_GET['lesson_id'] ?? ''));
        exit;
    }
}

// ۷. دریافت لیست پیام‌ها
$chats = $pdo->prepare("
    SELECT course_chats.*, users.full_name, users.avatar, users.role 
    FROM course_chats 
    JOIN users ON course_chats.user_id = users.id 
    WHERE course_id = ? 
    ORDER BY created_at ASC
");
$chats->execute([$course_id]);
$chat_history = $chats->fetchAll();






?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>کلاس: <?php echo $course_title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
    <style>body { font-family: 'Vazirmatn', sans-serif; }</style>
</head>
<body class="bg-gray-900 text-white min-h-screen flex flex-col">

    <header class="bg-gray-800 border-b border-gray-700 p-4 flex justify-between items-center shadow-md z-10">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="text-gray-400 hover:text-white transition">← بازگشت</a>
            <h1 class="font-bold text-lg hidden md:block border-r border-gray-600 pr-3 mr-3"><?php echo $course_title; ?></h1>
        </div>
        <div class="text-sm text-gray-400">
            دانشجو: <?php echo $_SESSION['full_name']; ?>
        </div>
    </header>

    <div class="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        <main class="flex-1 overflow-y-auto p-6 md:p-10 bg-gray-900 flex flex-col items-center">
            <?php if ($current_lesson): ?>
                <div class="w-full max-w-4xl">
                    <div class="aspect-video bg-black rounded-xl overflow-hidden shadow-2xl border border-gray-700 mb-6 relative group">
                        <iframe src="<?php echo $current_lesson['video_url']; ?>" class="w-full h-full" frameborder="0" allowfullscreen></iframe>
                    </div>

                    <h2 class="text-2xl font-bold mb-4"><?php echo $current_lesson['title']; ?></h2>
                    <div class="bg-gray-800 p-6 rounded-xl text-gray-300 leading-relaxed border border-gray-700">
                        <?php echo nl2br($current_lesson['content']); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="text-center text-gray-500 mt-20">
                    <p class="text-xl">هنوز درسی برای این دوره بارگذاری نشده است.</p>
                </div>
            <?php endif; ?>
        </main>

        <aside class="w-full md:w-80 bg-gray-800 border-r border-gray-700 overflow-y-auto shadow-xl">
            <div class="p-4 border-b border-gray-700 font-bold text-gray-300">
                سرفصل‌های دوره
            </div>
            <ul class="divide-y divide-gray-700">
                <?php foreach ($all_lessons as $index => $lesson): ?>
                <li>
                    <a href="classroom.php?course_id=<?php echo $course_id; ?>&lesson_id=<?php echo $lesson['id']; ?>" 
                       class="block p-4 hover:bg-gray-700 transition flex items-center gap-3 <?php echo ($active_lesson_id == $lesson['id']) ? 'bg-blue-900/50 border-r-4 border-blue-500' : ''; ?>">
                        <span class="bg-gray-700 text-xs w-6 h-6 flex items-center justify-center rounded-full text-gray-400">
                            <?php echo $index + 1; ?>
                        </span>
                        <span class="text-sm font-medium <?php echo ($active_lesson_id == $lesson['id']) ? 'text-white' : 'text-gray-400'; ?>">
                            <?php echo $lesson['title']; ?>
                        </span>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </aside>

    </div>




<aside class="w-full md:w-96 bg-gray-800 border-r border-gray-700 flex flex-col shadow-xl">
            
            <?php if ($teacher_info): ?>
            <div class="p-4 bg-gray-700/50 border-b border-gray-600 flex items-center gap-3">
                <img src="<?php echo $teacher_info['avatar'] ?: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'; ?>" class="w-10 h-10 rounded-full border-2 border-green-500">
                <div>
                    <div class="text-xs text-gray-400">مدرس دوره:</div>
                    <div class="font-bold text-sm text-white"><?php echo $teacher_info['full_name']; ?></div>
                </div>
            </div>
            <?php endif; ?>

            <div class="flex border-b border-gray-700 text-sm">
                <button onclick="switchTab('lessons')" id="btn-lessons" class="flex-1 py-3 bg-gray-700 text-white font-bold border-b-2 border-blue-500">📚 درس‌ها</button>
                <button onclick="switchTab('chat')" id="btn-chat" class="flex-1 py-3 text-gray-400 hover:text-white hover:bg-gray-700">💬 پرسش و پاسخ</button>
            </div>

            <div id="tab-lessons" class="flex-1 overflow-y-auto">
                <ul class="divide-y divide-gray-700">
                    <?php foreach ($all_lessons as $index => $lesson): ?>
                    <li>
                        <a href="classroom.php?course_id=<?php echo $course_id; ?>&lesson_id=<?php echo $lesson['id']; ?>" 
                           class="block p-4 hover:bg-gray-700 transition flex items-center gap-3 <?php echo ($active_lesson_id == $lesson['id']) ? 'bg-blue-900/40 text-blue-200' : 'text-gray-300'; ?>">
                            <span class="text-xs opacity-50">#<?php echo $index + 1; ?></span>
                            <span class="text-sm font-medium"><?php echo $lesson['title']; ?></span>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div id="tab-chat" class="hidden flex-1 flex flex-col bg-gray-800">
                <div class="flex-1 overflow-y-auto p-4 space-y-4" id="chat-box">
                    <?php if (empty($chat_history)): ?>
                        <div class="text-center text-gray-500 text-sm mt-10">هنوز سوالی پرسیده نشده.<br>اولین نفر باشید!</div>
                    <?php endif; ?>

                    <?php foreach ($chat_history as $msg): ?>
                        <?php $is_me = ($msg['user_id'] == $_SESSION['user_id']); ?>
                        <div class="flex gap-2 <?php echo $is_me ? 'flex-row-reverse' : ''; ?>">
                            <img src="<?php echo $msg['avatar'] ?: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'; ?>" class="w-8 h-8 rounded-full bg-gray-600">
                            <div class="max-w-[80%]">
                                <div class="bg-gray-700 p-3 rounded-xl text-sm leading-relaxed <?php echo $is_me ? 'bg-blue-600 text-white rounded-tr-none' : 'rounded-tl-none'; ?> <?php echo $msg['is_teacher_reply'] ? 'border border-green-500 shadow-[0_0_10px_rgba(34,197,94,0.3)]' : ''; ?>">
                                    <?php if($msg['is_teacher_reply']): ?>
                                        <span class="text-xs text-green-400 font-bold block mb-1">👨‍🏫 پاسخ مدرس</span>
                                    <?php endif; ?>
                                    <?php echo htmlspecialchars($msg['message']); ?>
                                </div>
                                <div class="text-[10px] text-gray-500 mt-1 px-1 <?php echo $is_me ? 'text-left' : 'text-right'; ?>">
                                    <?php echo $msg['full_name']; ?> • <?php echo date('H:i', strtotime($msg['created_at'])); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <form method="POST" class="p-3 bg-gray-900 border-t border-gray-700 flex gap-2">
                    <input type="text" name="chat_message" placeholder="سوال خود را بپرسید..." class="flex-1 bg-gray-800 text-white border border-gray-600 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" required>
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                    </button>
                </form>
            </div>

        </aside>

    <script>
        function switchTab(tabName) {
            // مخفی کردن همه
            document.getElementById('tab-lessons').classList.add('hidden');
            document.getElementById('tab-chat').classList.add('hidden');
            document.getElementById('btn-lessons').classList.remove('bg-gray-700', 'text-white', 'border-b-2', 'border-blue-500');
            document.getElementById('btn-chat').classList.remove('bg-gray-700', 'text-white', 'border-b-2', 'border-blue-500');
            document.getElementById('btn-lessons').classList.add('text-gray-400');
            document.getElementById('btn-chat').classList.add('text-gray-400');

            // نمایش تب انتخاب شده
            document.getElementById('tab-' + tabName).classList.remove('hidden');
            document.getElementById('btn-' + tabName).classList.add('bg-gray-700', 'text-white', 'border-b-2', 'border-blue-500');
            document.getElementById('btn-' + tabName).classList.remove('text-gray-400');
            
            // اسکرول چت به پایین
            if(tabName === 'chat') {
                var chatBox = document.getElementById('chat-box');
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        }
    </script>








</body>
</html>